
import React, { createContext, useState, useContext, ReactNode } from 'react';
import type { Booking, QuoteRequest } from '../types';

interface AppContextType {
  bookings: Booking[];
  addBooking: (booking: Omit<Booking, 'id'>) => void;
  quotes: QuoteRequest[];
  addQuote: (quote: QuoteRequest) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [quotes, setQuotes] = useState<QuoteRequest[]>([]);

  const addBooking = (booking: Omit<Booking, 'id'>) => {
    const newBooking: Booking = { ...booking, id: new Date().toISOString() };
    setBookings(prevBookings => [...prevBookings, newBooking]);
  };

  const addQuote = (quote: QuoteRequest) => {
    setQuotes(prevQuotes => [...prevQuotes, quote]);
  };

  return (
    <AppContext.Provider value={{ bookings, addBooking, quotes, addQuote }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
