
import React from 'react';
import { Link } from 'react-router-dom';
import { SERVICES } from '../constants';
import QuoteForm from '../components/QuoteForm';

const Home: React.FC = () => {
  const featuredServices = SERVICES.slice(0, 3);

  return (
    <div className="space-y-16 md:space-y-24">
      {/* Hero Section */}
      <section className="relative bg-cover bg-center text-white" style={{ backgroundImage: "url('https://picsum.photos/seed/hero-garden/1600/900')" }}>
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 flex flex-col items-center justify-center text-center min-h-[60vh] py-20">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">Pristine Properties, Made Simple.</h1>
          <p className="mt-4 max-w-2xl text-lg md:text-xl text-gray-200">
            PPMaintenance offers premium outdoor care for homes on the Northern Beaches. From lawns to gutters, we handle it all with our flexible subscription plans.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link to="/subscriptions" className="px-8 py-3 bg-emerald-500 rounded-md font-semibold text-white shadow-lg transition-all duration-300 hover:bg-emerald-600 hover:shadow-[0_0_15px_5px_rgba(134,239,172,0.5)] transform hover:-translate-y-1">
              Explore Subscriptions
            </Link>
            <Link to="/services" className="px-8 py-3 bg-white text-emerald-600 rounded-md font-semibold shadow-lg transition-all duration-300 hover:bg-gray-100 transform hover:-translate-y-1">
              View All Services
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Services Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Our Popular Services</h2>
            <p className="mt-4 text-lg text-gray-600">Tailored solutions for every aspect of your property.</p>
        </div>
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {featuredServices.map(service => (
            <div key={service.id} className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300">
              <img src={service.imageUrl} alt={service.name} className="h-56 w-full object-cover"/>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900">{service.name}</h3>
                <p className="mt-2 text-gray-600">{service.description}</p>
                <Link to="/services" className="mt-4 inline-block text-emerald-600 hover:text-emerald-800 font-semibold">Learn More &rarr;</Link>
              </div>
            </div>
          ))}
        </div>
      </section>

       {/* Subscription Highlight Section */}
      <section className="bg-emerald-50 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Flexible Care That Fits Your Life</h2>
            <p className="mt-4 text-lg text-gray-600">Our unique subscription model puts you in control. Choose your services, set the schedule, and enjoy a beautifully maintained property year-round. No lock-in contracts, just consistent, high-quality care.</p>
            <ul className="mt-6 space-y-4">
                <li className="flex items-start">
                    <svg className="flex-shrink-0 h-6 w-6 text-emerald-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                    <span className="ml-3 text-gray-700">Customize your plan with any of our services.</span>
                </li>
                <li className="flex items-start">
                    <svg className="flex-shrink-0 h-6 w-6 text-emerald-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                    <span className="ml-3 text-gray-700">Adjust frequency from weekly to quarterly.</span>
                </li>
                <li className="flex items-start">
                    <svg className="flex-shrink-0 h-6 w-6 text-emerald-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                    <span className="ml-3 text-gray-700">Simple, transparent pricing with no hidden fees.</span>
                </li>
            </ul>
             <div className="mt-8">
                 <Link to="/subscriptions" className="px-8 py-3 bg-emerald-500 rounded-md font-semibold text-white shadow-lg transition-all duration-300 hover:bg-emerald-600 hover:shadow-[0_0_15px_5px_rgba(134,239,172,0.5)] transform hover:-translate-y-1">
                    Build Your Plan
                </Link>
             </div>
          </div>
          <div className="rounded-lg overflow-hidden shadow-xl">
            <img src="https://picsum.photos/seed/subscription-highlight/800/600" alt="Well-maintained garden" className="w-full h-full object-cover"/>
          </div>
        </div>
      </section>

      {/* Free Quote Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Get a Free, No-Obligation Quote</h2>
            <p className="mt-4 text-lg text-gray-600">Curious about pricing for a one-off job? Fill out the form below and we'll get back to you with a detailed estimate.</p>
        </div>
        <div className="mt-12 max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-2xl">
            <QuoteForm />
        </div>
      </section>

    </div>
  );
};

export default Home;
