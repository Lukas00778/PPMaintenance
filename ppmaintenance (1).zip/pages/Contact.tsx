
import React from 'react';
import QuoteForm from '../components/QuoteForm';

const Contact: React.FC = () => {
    return (
        <div className="bg-gray-50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl">Get In Touch</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                        We're here to help. Reach out with any questions or for a free quote on your next project.
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                    {/* Contact Form */}
                    <div className="bg-white p-8 rounded-lg shadow-lg">
                        <h2 className="text-2xl font-bold text-gray-800 mb-6">Send us a message</h2>
                        <QuoteForm />
                    </div>

                    {/* Contact Info */}
                    <div className="bg-emerald-600 text-white p-8 rounded-lg shadow-lg">
                        <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
                        <div className="space-y-4">
                            <div className="flex items-start">
                                <svg className="flex-shrink-0 h-6 w-6 text-emerald-200 mt-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                <div className="ml-4">
                                    <h3 className="text-lg font-semibold">Address</h3>
                                    <p>Servicing the Northern Beaches, Sydney, NSW</p>
                                </div>
                            </div>
                             <div className="flex items-start">
                                <svg className="flex-shrink-0 h-6 w-6 text-emerald-200 mt-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                                <div className="ml-4">
                                    <h3 className="text-lg font-semibold">Phone</h3>
                                    <p>0400 123 456</p>
                                </div>
                            </div>
                             <div className="flex items-start">
                                <svg className="flex-shrink-0 h-6 w-6 text-emerald-200 mt-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                                <div className="ml-4">
                                    <h3 className="text-lg font-semibold">Email</h3>
                                    <p>info@ppmaintenance.com</p>
                                </div>
                            </div>
                        </div>
                        <div className="mt-8 pt-8 border-t border-emerald-500">
                             <h3 className="text-lg font-semibold">Business Hours</h3>
                             <p className="mt-2">Monday - Friday: 8:00 AM - 5:00 PM</p>
                             <p>Saturday: 9:00 AM - 2:00 PM</p>
                             <p>Sunday: Closed</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Contact;
