
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { SERVICES, FREQUENCY_OPTIONS, FREQUENCY_MULTIPLIERS } from '../constants';
import type { SelectedService } from '../types';
import { Frequency } from '../types';

const Subscriptions: React.FC = () => {
    const [selectedServices, setSelectedServices] = useState<SelectedService[]>([]);

    const handleServiceSelection = (serviceId: string, frequency: string) => {
        const existingService = selectedServices.find(s => s.serviceId === serviceId);
        if (existingService) {
            if (frequency === 'None') {
                setSelectedServices(prev => prev.filter(s => s.serviceId !== serviceId));
            } else {
                setSelectedServices(prev => prev.map(s => s.serviceId === serviceId ? { ...s, frequency } : s));
            }
        } else if (frequency !== 'None') {
            setSelectedServices(prev => [...prev, { serviceId, frequency }]);
        }
    };

    const { monthlyCost, quarterlyCost } = useMemo(() => {
        let monthly = 0;
        let quarterly = 0;
        
        selectedServices.forEach(selected => {
            const service = SERVICES.find(s => s.id === selected.serviceId);
            if(service) {
                const multipliers = FREQUENCY_MULTIPLIERS[selected.frequency as Frequency];
                monthly += service.price * multipliers.monthly;
                quarterly += service.price * multipliers.quarterly;
            }
        });

        return { monthlyCost: monthly, quarterlyCost: quarterly };
    }, [selectedServices]);


    return (
        <div className="bg-emerald-50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl">Build Your Perfect Plan</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
                        Select the services you need and how often you need them. Your custom care plan, calculated instantly.
                    </p>
                </div>

                <div className="flex flex-col lg:flex-row gap-8">
                    {/* Services Selection */}
                    <div className="lg:w-2/3 bg-white p-8 rounded-lg shadow-xl space-y-6">
                        <h2 className="text-2xl font-bold">1. Choose Your Services</h2>
                        <div className="space-y-4">
                            {SERVICES.map(service => (
                                <div key={service.id} className="p-4 border rounded-md flex flex-col sm:flex-row justify-between items-center gap-4">
                                    <div>
                                        <h3 className="font-semibold text-lg">{service.name}</h3>
                                        <p className="text-sm text-gray-500">{service.description}</p>
                                    </div>
                                    <select 
                                        onChange={(e) => handleServiceSelection(service.id, e.target.value)}
                                        className="p-2 border border-gray-300 rounded-md w-full sm:w-48 focus:ring-emerald-500 focus:border-emerald-500"
                                        aria-label={`Frequency for ${service.name}`}
                                    >
                                        <option value="None">None</option>
                                        {FREQUENCY_OPTIONS.map(freq => (
                                            <option key={freq} value={freq}>{freq}</option>
                                        ))}
                                    </select>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Cost Summary */}
                    <div className="lg:w-1/3">
                         <div className="sticky top-24 bg-white p-8 rounded-lg shadow-xl">
                            <h2 className="text-2xl font-bold">2. Your Custom Plan</h2>
                             {selectedServices.length === 0 ? (
                                <p className="mt-4 text-gray-600">Select services on the left to see your estimated cost.</p>
                             ) : (
                                <>
                                 <ul className="mt-4 space-y-2 divide-y">
                                     {selectedServices.map(sel => {
                                         const service = SERVICES.find(s => s.id === sel.serviceId);
                                         return (
                                             <li key={sel.serviceId} className="pt-2 flex justify-between items-center">
                                                 <div>
                                                     <p className="font-semibold">{service?.name}</p>
                                                     <p className="text-sm text-gray-500">{sel.frequency}</p>
                                                 </div>
                                                  <p className="font-medium">${service?.price}/hr</p>
                                             </li>
                                         )
                                     })}
                                 </ul>

                                 <div className="mt-6 pt-6 border-t">
                                     <div className="flex justify-between items-baseline">
                                         <p className="text-lg">Monthly Total:</p>
                                         <p className="text-3xl font-bold text-emerald-600">${monthlyCost.toFixed(2)}</p>
                                     </div>
                                      <div className="flex justify-between items-baseline mt-2">
                                         <p className="text-lg">Quarterly Total:</p>
                                         <p className="text-3xl font-bold text-emerald-600">${quarterlyCost.toFixed(2)}</p>
                                     </div>
                                 </div>
                                 
                                 <Link 
                                    to="/booking"
                                    state={{ subscription: selectedServices, monthlyCost, quarterlyCost }} 
                                    className="mt-8 w-full block text-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-all duration-300 hover:shadow-[0_0_15px_5px_rgba(134,239,172,0.5)]"
                                >
                                    Proceed to Booking
                                </Link>
                                </>
                             )}
                         </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Subscriptions;
