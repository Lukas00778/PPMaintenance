
import React from 'react';
import { Link } from 'react-router-dom';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  return (
    <div className="bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-5xl">Our Services</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Comprehensive care for every corner of your property.
          </p>
        </div>

        <div className="space-y-16">
            {SERVICES.map((service, index) => (
                <div key={service.id} className={`flex flex-col md:flex-row items-center gap-8 md:gap-12 ${index % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}>
                    <div className="md:w-1/2">
                        <img src={service.imageUrl} alt={service.name} className="rounded-lg shadow-2xl w-full h-auto object-cover aspect-video" />
                    </div>
                    <div className="md:w-1/2">
                        <h2 className="text-3xl font-bold text-gray-900">{service.name}</h2>
                        <p className="mt-4 text-lg text-gray-600">{service.description}</p>
                        <ul className="mt-6 space-y-2">
                           {service.details.map((detail, i) => (
                               <li key={i} className="flex items-center">
                                   <svg className="flex-shrink-0 h-5 w-5 text-emerald-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                       <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                                   </svg>
                                   <span className="ml-3 text-gray-700">{detail}</span>
                               </li>
                           ))}
                        </ul>
                         <p className="mt-4 text-2xl font-bold text-gray-800">${service.price}<span className="text-base font-normal text-gray-500">/hr</span></p>
                        <div className="mt-8">
                            <Link to="/booking" className="inline-block px-8 py-3 bg-emerald-600 text-white font-semibold rounded-lg shadow-md hover:bg-emerald-700 transition-all duration-300 hover:shadow-[0_0_15px_5px_rgba(134,239,172,0.5)]">
                                Book This Service
                            </Link>
                        </div>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default Services;
