
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="bg-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="container mx-auto">
        <div className="text-center">
          <h2 className="text-base font-semibold text-emerald-600 tracking-wide uppercase">About Us</h2>
          <p className="mt-1 text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">We Love the Northern Beaches.</p>
          <p className="max-w-xl mt-5 mx-auto text-xl text-gray-500">And we believe every property here deserves to look its absolute best.</p>
        </div>

        <div className="mt-12 grid gap-16 lg:grid-cols-2 lg:gap-x-12 lg:gap-y-12 items-center">
          <div>
            <h3 className="text-2xl font-bold text-gray-900">Our Story</h3>
            <p className="mt-4 text-lg text-gray-600">
              PPMaintenance was born from a simple idea: to provide reliable, high-quality property maintenance with a personal touch. As long-time residents of the Northern Beaches, we saw a need for a service that not only understands the local environment but also offers the flexibility modern homeowners need. We're not just a business; we're your neighbors, dedicated to enhancing the beauty and value of our shared community.
            </p>
            <h3 className="mt-8 text-2xl font-bold text-gray-900">Our Mission</h3>
            <p className="mt-4 text-lg text-gray-600">
              Our mission is to simplify property care. Through our innovative subscription model, we empower you to create a customized maintenance plan that fits your schedule and budget. We're committed to using eco-friendly practices, delivering exceptional results, and building lasting relationships with our clients based on trust and transparency.
            </p>
          </div>
          <div className="rounded-lg shadow-xl overflow-hidden">
            <img className="w-full h-full object-cover" src="https://picsum.photos/seed/about-us/800/900" alt="Team working in a garden" />
          </div>
        </div>

        <div className="mt-20">
            <h2 className="text-3xl font-extrabold text-gray-900 text-center">Why Choose Us?</h2>
            <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-10">
                <div className="text-center">
                    <div className="flex items-center justify-center h-12 w-12 rounded-md bg-emerald-500 text-white mx-auto">
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                    </div>
                    <h3 className="mt-5 text-lg font-medium text-gray-900">Local Experts</h3>
                    <p className="mt-2 text-base text-gray-500">We live and work on the Northern Beaches, giving us unparalleled knowledge of local conditions.</p>
                </div>
                <div className="text-center">
                     <div className="flex items-center justify-center h-12 w-12 rounded-md bg-emerald-500 text-white mx-auto">
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    </div>
                    <h3 className="mt-5 text-lg font-medium text-gray-900">Quality Guaranteed</h3>
                    <p className="mt-2 text-base text-gray-500">We take pride in our work and aren't happy unless you are. We guarantee your satisfaction.</p>
                </div>
                 <div className="text-center">
                     <div className="flex items-center justify-center h-12 w-12 rounded-md bg-emerald-500 text-white mx-auto">
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    </div>
                    <h3 className="mt-5 text-lg font-medium text-gray-900">Flexible & Reliable</h3>
                    <p className="mt-2 text-base text-gray-500">Our subscription model is designed for your convenience. We show up on time, every time.</p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default About;
