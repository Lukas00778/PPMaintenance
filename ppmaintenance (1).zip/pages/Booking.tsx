
import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { SERVICES } from '../constants';
import { useAppContext } from '../context/AppContext';
import { BookingType } from '../types';

const Booking: React.FC = () => {
    const { addBooking, bookings } = useAppContext();
    const location = useLocation();
    const { subscription, monthlyCost, quarterlyCost } = location.state || {};
    
    const [bookingType, setBookingType] = useState<BookingType>(subscription ? BookingType.SUBSCRIPTION : BookingType.ONETIME);
    const [serviceId, setServiceId] = useState(SERVICES[0].id);
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [customerName, setCustomerName] = useState('');
    const [customerEmail, setCustomerEmail] = useState('');
    const [isConfirmed, setIsConfirmed] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (bookingType === BookingType.ONETIME) {
            addBooking({ serviceId, date, time, type: BookingType.ONETIME, customerName, customerEmail });
        } else {
            // In a real app, this would trigger a more complex subscription setup flow.
            // For now, we'll create a placeholder booking for the first service in the plan.
            const firstServiceId = subscription[0]?.serviceId || SERVICES[0].id;
            addBooking({ serviceId: firstServiceId, date, time, type: BookingType.SUBSCRIPTION, customerName, customerEmail });
        }
        
        setIsConfirmed(true);
    };

    if (isConfirmed) {
        return (
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
                <div className="bg-white p-10 rounded-lg shadow-xl max-w-2xl mx-auto">
                    <h2 className="text-3xl font-bold text-emerald-600">Booking Confirmed!</h2>
                    <p className="mt-4 text-lg text-gray-700">Thank you, {customerName}. Your appointment has been scheduled.</p>
                    <p className="mt-2 text-gray-600">A confirmation email with the details has been sent to {customerEmail}.</p>
                    <div className="mt-8 text-left bg-gray-50 p-6 rounded-md">
                        <h3 className="font-semibold text-lg">Your Upcoming Appointments:</h3>
                        <ul className="mt-4 space-y-3">
                           {bookings.map(b => {
                                const service = SERVICES.find(s => s.id === b.serviceId);
                                return (
                                <li key={b.id} className="p-3 bg-white border rounded-md">
                                    <p className="font-bold">{service?.name} ({b.type})</p>
                                    <p className="text-sm text-gray-600">Date: {new Date(b.date).toLocaleDateString()} at {b.time}</p>
                                </li>
                                );
                            })}
                        </ul>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="max-w-3xl mx-auto">
                <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 text-center">Schedule Your Service</h1>
                <p className="mt-4 text-center text-xl text-gray-500">Confirm your details and choose a convenient time for us to visit.</p>

                <div className="mt-10 bg-white p-8 rounded-lg shadow-2xl">
                    <div className="mb-6">
                        <div className="flex border border-gray-200 rounded-lg p-1">
                            <button onClick={() => setBookingType(BookingType.ONETIME)} disabled={!!subscription} className={`w-1/2 p-2 rounded-md font-semibold transition-colors ${bookingType === BookingType.ONETIME ? 'bg-emerald-500 text-white' : 'text-gray-600 hover:bg-gray-100'} ${!!subscription ? 'cursor-not-allowed opacity-50' : ''}`}>
                                One-Time Service
                            </button>
                             <button onClick={() => setBookingType(BookingType.SUBSCRIPTION)} className={`w-1/2 p-2 rounded-md font-semibold transition-colors ${bookingType === BookingType.SUBSCRIPTION ? 'bg-emerald-500 text-white' : 'text-gray-600 hover:bg-gray-100'}`}>
                                Subscription Plan
                            </button>
                        </div>
                    </div>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        {bookingType === BookingType.ONETIME ? (
                             <div>
                                <label htmlFor="serviceId" className="block text-sm font-medium text-gray-700">Service</label>
                                <select id="serviceId" value={serviceId} onChange={e => setServiceId(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500">
                                    {SERVICES.map(service => <option key={service.id} value={service.id}>{service.name}</option>)}
                                </select>
                            </div>
                        ) : (
                            <div className="p-4 bg-emerald-50 rounded-md">
                               <h3 className="font-semibold text-lg text-emerald-800">Your Subscription Plan</h3>
                               {subscription ? (
                                   <>
                                    <ul className="mt-2 space-y-1 text-sm text-emerald-700">
                                        {subscription.map((s: any) => {
                                            const service = SERVICES.find(serv => serv.id === s.serviceId);
                                            return <li key={s.serviceId}><strong>{service?.name}</strong> - {s.frequency}</li>
                                        })}
                                    </ul>
                                    <p className="mt-3 font-bold text-emerald-900">Monthly: ${monthlyCost.toFixed(2)} | Quarterly: ${quarterlyCost.toFixed(2)}</p>
                                   </>
                               ) : (
                                   <p className="text-gray-600">Please build your plan on the Subscriptions page first.</p>
                               )}
                            </div>
                        )}
                        <p className="text-sm text-gray-600">Please enter your details and preferred start date for your services.</p>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="customerName" className="block text-sm font-medium text-gray-700">Full Name</label>
                                <input type="text" id="customerName" value={customerName} onChange={e => setCustomerName(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"/>
                            </div>
                            <div>
                                <label htmlFor="customerEmail" className="block text-sm font-medium text-gray-700">Email</label>
                                <input type="email" id="customerEmail" value={customerEmail} onChange={e => setCustomerEmail(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"/>
                            </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="date" className="block text-sm font-medium text-gray-700">{bookingType === BookingType.SUBSCRIPTION ? 'Preferred Start Date' : 'Preferred Date'}</label>
                                <input type="date" id="date" value={date} onChange={e => setDate(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"/>
                            </div>
                            <div>
                                <label htmlFor="time" className="block text-sm font-medium text-gray-700">Preferred Time</label>
                                <input type="time" id="time" value={time} onChange={e => setTime(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"/>
                            </div>
                        </div>
                         <div>
                            <button type="submit" disabled={bookingType === BookingType.SUBSCRIPTION && !subscription} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-all duration-300 hover:shadow-[0_0_15px_5px_rgba(134,239,172,0.5)] disabled:bg-gray-400 disabled:cursor-not-allowed disabled:shadow-none">
                                Confirm Booking
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Booking;
