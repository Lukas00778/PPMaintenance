
import React, { useState } from 'react';
import { SERVICES } from '../constants';
import { useAppContext } from '../context/AppContext';
import type { QuoteRequest } from '../types';

const QuoteForm: React.FC = () => {
    const { addQuote } = useAppContext();
    const [formData, setFormData] = useState<Omit<QuoteRequest, 'services'>>({
        fullName: '',
        email: '',
        address: '',
        message: '',
    });
    const [selectedServices, setSelectedServices] = useState<string[]>([]);
    const [submitted, setSubmitted] = useState(false);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleServiceToggle = (serviceId: string) => {
        setSelectedServices(prev => 
            prev.includes(serviceId) 
                ? prev.filter(id => id !== serviceId)
                : [...prev, serviceId]
        );
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const quoteRequest: QuoteRequest = {
            ...formData,
            services: selectedServices,
        };
        addQuote(quoteRequest);
        console.log('Quote Request:', quoteRequest);
        setSubmitted(true);
    };

    if (submitted) {
        return (
            <div className="text-center p-8 bg-emerald-100 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold text-emerald-800">Thank You!</h3>
                <p className="mt-2 text-emerald-700">Your quote request has been received. We will get back to you within 24 hours.</p>
            </div>
        );
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">Full Name</label>
                    <input type="text" name="fullName" id="fullName" required value={formData.fullName} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"/>
                </div>
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" name="email" id="email" required value={formData.email} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"/>
                </div>
            </div>
            <div>
                <label htmlFor="address" className="block text-sm font-medium text-gray-700">Property Address (Optional)</label>
                <input type="text" name="address" id="address" value={formData.address} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"/>
            </div>
             <div>
                <label className="block text-sm font-medium text-gray-700">Services Needed</label>
                <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {SERVICES.map(service => (
                        <button 
                            type="button" 
                            key={service.id} 
                            onClick={() => handleServiceToggle(service.id)}
                            className={`px-3 py-2 text-sm rounded-md transition-colors duration-200 ${selectedServices.includes(service.id) ? 'bg-emerald-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
                        >
                            {service.name}
                        </button>
                    ))}
                </div>
            </div>
            <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">Additional Details</label>
                <textarea name="message" id="message" rows={4} required value={formData.message} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"></textarea>
            </div>
            <div>
                <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-all duration-300 hover:shadow-[0_0_15px_5px_rgba(134,239,172,0.5)]">
                    Get My Free Quote
                </button>
            </div>
        </form>
    );
};

export default QuoteForm;
