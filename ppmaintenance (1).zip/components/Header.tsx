
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const NavItem: React.FC<{ to: string; children: React.ReactNode }> = ({ to, children }) => {
    const activeStyle = {
      color: '#10B981', // emerald-500
      boxShadow: '0 0 15px 5px rgba(52, 211, 153, 0.4)', // emerald-400 glow
    };

    return (
        <NavLink
            to={to}
            className="px-4 py-2 rounded-md text-sm lg:text-base font-medium text-gray-700 transition-all duration-300 hover:text-emerald-600 hover:shadow-[0_0_15px_5px_rgba(134,239,172,0.5)]"
            style={({ isActive }) => (isActive ? activeStyle : {})}
        >
            {children}
        </NavLink>
    );
};


const Header: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex-shrink-0">
            <NavLink to="/" className="flex items-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-emerald-500" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM.7 10a9.3 9.3 0 013.297-7.143l-2.22 2.22a.75.75 0 001.06 1.06l2.353-2.353A9.3 9.3 0 0110 .7v3.05a.75.75 0 001.5 0V.7a9.3 9.3 0 017.143 3.297l-2.22 2.22a.75.75 0 101.06 1.06l2.353-2.353A9.3 9.3 0 0119.3 10h-3.05a.75.75 0 000 1.5h3.05a9.3 9.3 0 01-3.297 7.143l2.22-2.22a.75.75 0 10-1.06-1.06l-2.353 2.353A9.3 9.3 0 0110 19.3v-3.05a.75.75 0 00-1.5 0v3.05a9.3 9.3 0 01-7.143-3.297l2.22-2.22a.75.75 0 00-1.06-1.06L1.757 12.86A9.3 9.3 0 01.7 10zm1.05 1.5a.75.75 0 000-1.5H.7a.75.75 0 000 1.5h1.05zM10 4.5a.75.75 0 00-1.5 0v2.536l-1.622 1.622a.75.75 0 101.06 1.06L9.25 8.443V10a.75.75 0 001.5 0V4.5z" clipRule="evenodd" />
                </svg>
               <span className="text-2xl font-bold text-gray-800">PPMaintenance</span>
            </NavLink>
          </div>
          <div className="hidden md:block">
            <nav className="ml-10 flex items-baseline space-x-4">
              <NavItem to="/">Home</NavItem>
              <NavItem to="/services">Services</NavItem>
              <NavItem to="/subscriptions">Subscriptions</NavItem>
              <NavItem to="/about">About Us</NavItem>
              <NavItem to="/contact">Contact</NavItem>
              <NavItem to="/booking">Book Now</NavItem>
            </nav>
          </div>
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              type="button"
              className="bg-emerald-100 inline-flex items-center justify-center p-2 rounded-md text-emerald-600 hover:text-white hover:bg-emerald-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-emerald-100 focus:ring-white"
              aria-controls="mobile-menu"
              aria-expanded="false"
            >
              <span className="sr-only">Open main menu</span>
              {!isOpen ? (
                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              ) : (
                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>
      {isOpen && (
        <div className="md:hidden" id="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 text-center">
            <NavItem to="/">Home</NavItem>
            <NavItem to="/services">Services</NavItem>
            <NavItem to="/subscriptions">Subscriptions</NavItem>
            <NavItem to="/about">About Us</NavItem>
            <NavItem to="/contact">Contact</NavItem>
            <NavItem to="/booking">Book Now</NavItem>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
