
import type { Service } from './types';
import { Frequency } from './types';

export const SERVICES: Service[] = [
  {
    id: 'lawn-mowing',
    name: 'Lawn Mowing & Edging',
    description: 'Professional mowing and crisp edging for a pristine lawn.',
    price: 50,
    imageUrl: 'https://picsum.photos/seed/lawn-mowing/800/600',
    details: ['Precision Mowing', 'Sharp Edging', 'Debris Cleanup', 'Striping Available'],
  },
  {
    id: 'hedging',
    name: 'Hedging & Trimming',
    description: 'Expert shaping and trimming for healthy, beautiful hedges.',
    price: 70,
    imageUrl: 'https://picsum.photos/seed/hedging/800/600',
    details: ['Artistic Shaping', 'Health Trimming', 'Height Reduction', 'Waste Removal'],
  },
  {
    id: 'car-cleaning',
    name: 'Car Cleaning (Interior & Exterior)',
    description: 'A complete detailing service to make your car shine.',
    price: 70,
    imageUrl: 'https://picsum.photos/seed/car-cleaning/800/600',
    details: ['Exterior Wash & Wax', 'Interior Vacuum & Wipe Down', 'Tire Shine', 'Window Cleaning'],
  },
  {
    id: 'pressure-washing',
    name: 'Pressure Washing',
    description: 'High-pressure cleaning for driveways, paths, and patios.',
    price: 100,
    imageUrl: 'https://picsum.photos/seed/pressure-washing/800/600',
    details: ['Driveway & Sidewalks', 'Deck & Patio Cleaning', 'Siding Wash', 'Mold & Algae Removal'],
  },
  {
    id: 'gutter-cleaning',
    name: 'Gutter Cleaning',
    description: 'Ensure proper water flow by removing leaves and debris.',
    price: 80,
    imageUrl: 'https://picsum.photos/seed/gutter-cleaning/800/600',
    details: ['Debris Removal', 'Downspout Flushing', 'Minor Repair Inspection', 'Roof Sweep'],
  },
  {
    id: 'pruning',
    name: 'Pruning',
    description: 'Selective pruning to improve plant health and structure.',
    price: 40,
    imageUrl: 'https://picsum.photos/seed/pruning/800/600',
    details: ['Fruit Tree Pruning', 'Rose Bush Care', 'Shrub Shaping', 'Deadwood Removal'],
  },
  {
    id: 'general-labour',
    name: 'General Labour',
    description: 'An extra pair of hands for various outdoor tasks.',
    price: 30,
    imageUrl: 'https://picsum.photos/seed/general-labour/800/600',
    details: ['Garden Weeding', 'Mulch Spreading', 'Yard Cleanup', 'Small Item Hauling'],
  },
];

export const FREQUENCY_OPTIONS: Frequency[] = [
  Frequency.WEEKLY,
  Frequency.FORTNIGHTLY,
  Frequency.MONTHLY,
  Frequency.QUARTERLY,
];

export const FREQUENCY_MULTIPLIERS: { [key in Frequency]: { monthly: number; quarterly: number } } = {
  [Frequency.WEEKLY]: { monthly: 4, quarterly: 12 },
  [Frequency.FORTNIGHTLY]: { monthly: 2, quarterly: 6 },
  [Frequency.MONTHLY]: { monthly: 1, quarterly: 3 },
  [Frequency.QUARTERLY]: { monthly: 1 / 3, quarterly: 1 },
};
