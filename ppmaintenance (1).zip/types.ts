
export interface Service {
  id: string;
  name: string;
  description: string;
  price: number; // Price per hour
  imageUrl: string;
  details: string[];
}

export interface SelectedService {
  serviceId: string;
  frequency: string;
}

export interface QuoteRequest {
  fullName: string;
  email: string;
  address?: string;
  message: string;
  services: string[];
}

export enum BookingType {
    ONETIME = 'One-Time',
    SUBSCRIPTION = 'Subscription',
}

export interface Booking {
    id: string;
    serviceId: string;
    date: string;
    time: string;
    type: BookingType;
    customerName: string;
    customerEmail: string;
}

export enum Frequency {
    WEEKLY = 'Weekly',
    FORTNIGHTLY = 'Fortnightly',
    MONTHLY = 'Monthly',
    QUARTERLY = 'Quarterly',
}
